export const environment = {
  production: false,
  url : 'ciao from local'
};
